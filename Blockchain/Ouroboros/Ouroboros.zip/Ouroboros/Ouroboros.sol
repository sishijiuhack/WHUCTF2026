// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract Ouroboros {
    mapping(address => uint256) public balances;
    mapping(address => uint256) public loopDepth;
    mapping(address => bool) public tailUnlocked;

    address public immutable shedder;
    uint64 public immutable birthNonce;
    uint256 public immutable initialTreasury;
    bytes32 public immutable firstHalfCommitment;

    bytes private encryptedTail;
    bytes32 private tailMask;

    bool private insideWithdraw;
    address private currentCycler;
    bool public tailConfigured;

    event GenesisTrace(bytes coiledHead, uint64 birthNonce, address indexed shedder);
    event Deposit(address indexed from, uint256 amount);
    event Loop(address indexed player, uint256 depth, uint256 vaultBalance);
    event TailUnlockedFor(address indexed player, uint256 depth);
    event TailConfigured(uint256 cipherLength);

    modifier onlyShedder() {
        require(msg.sender == shedder, "not shedder");
        _;
    }

    constructor(bytes memory coiledHead, uint64 _birthNonce, bytes32 _firstHalfCommitment) payable {
        shedder = msg.sender;
        birthNonce = _birthNonce;
        firstHalfCommitment = _firstHalfCommitment;
        initialTreasury = msg.value;

        bytes32 prevHash = block.number > 0 ? blockhash(block.number - 1) : bytes32(0);
        tailMask = keccak256(
            abi.encodePacked(prevHash, block.timestamp, address(this), "ouroboros-tail-mask")
        );

        emit GenesisTrace(coiledHead, _birthNonce, msg.sender);
    }

    function setTailCipher(bytes calldata cipher) external onlyShedder {
        require(!tailConfigured, "tail already configured");
        encryptedTail = cipher;
        tailConfigured = true;
        emit TailConfigured(cipher.length);
    }

    function deposit() external payable {
        require(msg.value > 0, "value=0");
        balances[msg.sender] += msg.value;
        emit Deposit(msg.sender, msg.value);
    }

    // Deliberately vulnerable: external call happens before state update and uses stale balance snapshot.
    function withdraw(uint256 amount) external {
        uint256 cached = balances[msg.sender];
        require(amount > 0, "amount=0");
        require(cached >= amount, "insufficient");

        if (insideWithdraw && msg.sender == currentCycler) {
            loopDepth[msg.sender] += 1;
            emit Loop(msg.sender, loopDepth[msg.sender], address(this).balance);

            if (!tailUnlocked[msg.sender] && loopDepth[msg.sender] >= 2) {
                tailUnlocked[msg.sender] = true;
                emit TailUnlockedFor(msg.sender, loopDepth[msg.sender]);
            }
        }

        insideWithdraw = true;
        currentCycler = msg.sender;

        (bool ok, ) = msg.sender.call{value: amount}("");
        require(ok, "send failed");

        balances[msg.sender] = cached - amount;

        insideWithdraw = false;
        currentCycler = address(0);
    }

    function revealSecondHalf() external view returns (string memory) {
        require(tailConfigured, "tail not configured");
        require(tailUnlocked[msg.sender], "bite your tail first");
        bytes memory plain = _xorBytes(encryptedTail, abi.encodePacked(tailMask));
        return string(plain);
    }

    function verifyFirstHalf(string calldata guess) external view returns (bool) {
        return keccak256(bytes(guess)) == firstHalfCommitment;
    }

    function ouroboricEcho(uint256 depth) external pure returns (bytes32) {
        return _echo(depth);
    }

    function _echo(uint256 depth) internal pure returns (bytes32) {
        if (depth == 0) {
            return keccak256("ouroboros");
        }
        return keccak256(abi.encodePacked(_echo(depth - 1), depth));
    }

    function _xorBytes(bytes memory data, bytes memory mask) internal pure returns (bytes memory out) {
        require(mask.length > 0, "mask empty");
        out = new bytes(data.length);
        for (uint256 i = 0; i < data.length; i++) {
            out[i] = data[i] ^ mask[i % mask.length];
        }
    }
}
